/*Copyright (c) 2021-2022 truboardpartners.com All Rights Reserved.
 This software is the confidential and proprietary information of truboardpartners.com You shall not disclose such Confidential Information and shall use it only in accordance
 with the terms of the source code license agreement you entered into with truboardpartners.com*/
package com.truboardpartners.textutil.classifymodel;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;


import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import com.wavemaker.runtime.service.annotations.HideFromClient;


public class Classifymodel {

    private static final Logger logger = LoggerFactory.getLogger(Classifymodel.class);
//  private String Organization;
//   private String DocumentName;
//   private String Section;
//   private String PageNumber;
//   private String ClauseNo;
//   private String Clause;

//     public String getOrganization(){
//         return this.Organization;
//     }
//     public String getDocumentName(){
//         return this.DocumentName;
//     }
//     public String getSection(){
//         return this.Section;
//     }
//     public String getPageNumber(){
//         return this.PageNumber;
//     }
//     public String getClauseNo(){
//         return this.ClauseNo;
//     }
//     public String getClause(){
//         return this.Clause;
//     }
//   public Classifymodel(){}
//   public Classifymodel(String Organization, String DocumentName,String Section,String  PageNumber, String ClauseNo, String Clause) {
//     this.Organization = Organization;
//     this.DocumentName = DocumentName;
//     this.Section = Section;
//     this.PageNumber = PageNumber;
//      this.ClauseNo = ClauseNo;
//     this.Clause = Clause;
//   }
private String Section;
    private String PageNumber;
    private String ClauseNo;
    private String Clause;
    private String Tag_1_Applicability ;
    private String Tag_2_Area;
    private String Tag_3_CovenantType;
    private String Tag_4_CovenantTitle;
    private String Tag_5_CovenantDescription;
    private String ComplianceFrequency;
    private String TriggerType;
    private String FirstTriggerDate;
    private String SubmissionPeriodEndDate;
    private String Threshold;
    private String SubmissionPeriod;
    private String EndDate;

    public String getTag_2_Area(){
        return this.Tag_2_Area;
    }
    public String getTag_3_CovenantType(){
        return this.Tag_3_CovenantType;
    }
    public String getTag_4_CovenantTitle(){
        return this.Tag_4_CovenantTitle;
    }
    public String getTag_5_CovenantDescription(){
        return this.Tag_5_CovenantDescription;
    }
    public String getComplianceFrequency(){
        return this.ComplianceFrequency;
    }
    public String getTriggerType(){
        return this.TriggerType;
    }
    public String getFirstTriggerDate(){
        return this.FirstTriggerDate;
    }
    public String getSubmissionPeriodEndDate(){
        return this.SubmissionPeriodEndDate;
    }
    public String getThreshold(){
        return this.Threshold;
    }
    public String getSubmissionPeriod(){
        return this.SubmissionPeriod;
    }
    public String getEndDate(){
        return this.EndDate;
    }
    
    public String getTag_1_Applicability(){
        return this.Tag_1_Applicability;
    }
    public String getSection(){
        return this.Section;
    }
    public String getPageNumber(){
        return this.PageNumber;
    }
    public String getClauseNo(){
        return this.ClauseNo;
    }
    public String getClause(){
        return this.Clause;
    }
   public Classifymodel(){}
   public Classifymodel(String Section,String  PageNumber, String ClauseNo, String Clause, String Tag_1_Applicability,
     String Tag_2_Area,
     String Tag_3_CovenantType,
     String Tag_4_CovenantTitle,
     String Tag_5_CovenantDescription,
     String ComplianceFrequency,
     String TriggerType,
     String FirstTriggerDate,
     String SubmissionPeriodEndDate,
     String Threshold,
     String SubmissionPeriod,
     String EndDate) {
     this.Section = Section;
     this.PageNumber = PageNumber;
     this.ClauseNo = ClauseNo;
     this.Clause = Clause;
     this.Tag_1_Applicability=Tag_1_Applicability;
     this.Tag_2_Area=Tag_2_Area;
     this.Tag_3_CovenantType=Tag_3_CovenantType;
     this.Tag_4_CovenantTitle=Tag_4_CovenantTitle;
     this.Tag_5_CovenantDescription=Tag_5_CovenantDescription;
     this.ComplianceFrequency=ComplianceFrequency;
     this.TriggerType=TriggerType;
     this.FirstTriggerDate=FirstTriggerDate;
     this.SubmissionPeriodEndDate=SubmissionPeriodEndDate;
     this.Threshold=Threshold;
     this.SubmissionPeriod=SubmissionPeriod;
     this.EndDate=EndDate;
  }
    

}


