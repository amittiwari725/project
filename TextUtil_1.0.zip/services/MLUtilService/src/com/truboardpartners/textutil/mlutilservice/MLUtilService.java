/*Copyright (c) 2021-2022 truboardpartners.com All Rights Reserved.
 This software is the confidential and proprietary information of truboardpartners.com You shall not disclose such Confidential Information and shall use it only in accordance
 with the terms of the source code license agreement you entered into with truboardpartners.com*/
package com.truboardpartners.textutil.mlutilservice;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import com.wavemaker.runtime.service.annotations.HideFromClient;
import com.truboardpartners.textutil.classifymodel.Classifymodel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.microsoft.sqlserver.jdbc.SQLServerDataTable;
import com.microsoft.sqlserver.jdbc.SQLServerException;
import com.microsoft.sqlserver.jdbc.SQLServerPreparedStatement;

import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.BufferedInputStream;

import javax.annotation.PostConstruct;

import java.util.List;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.FileReader;
import java.util.Arrays;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.dataformat.csv.*;

import java.io.*;
import java.util.*;
import com.google.gson.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;


import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
/**
 * This is a singleton class with all its public methods exposed as REST APIs via generated controller class.
 * To avoid exposing an API for a particular public method, annotate it with @HideFromClient.
 *
 * Method names will play a major role in defining the Http Method for the generated APIs. For example, a method name
 * that starts with delete/remove, will make the API exposed as Http Method "DELETE".
 *
 * Method Parameters of type primitives (including java.lang.String) will be exposed as Query Parameters &
 * Complex Types/Objects will become part of the Request body in the generated API.
 *
 * NOTE: We do not recommend using method overloading on client exposed methods.
 */
@ExposeToClient
public class MLUtilService {

    private static final Logger logger = LoggerFactory.getLogger(MLUtilService.class);
    public static String getCovenantsURL="https://3.7.249.68/covenants?document_id=";
        // private static final Logger logger = LoggerFactory.getLogger(AddAssetDatabaseService.class);
    final public static String DB_URL = "jdbc:sqlserver://truboard.database.windows.net:1433;database=textutil";
	final public static String DB_USERNAME = "amit";
	final public static String DB_PASSWORD = "bf7GkSzLu(J9";

    @Autowired
    private SecurityService securityService;
    
    private File uploadDirectory = null;
    
    protected Connection getConnection() throws SQLException {
	    try {
			Connection connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
			return connection;
		} catch (Exception e) {
			e.printStackTrace();
			throw new SQLException(e);
		}

	}
	public static Map<String, Object> ConvertObjectToMap(Object obj) throws 
    IllegalAccessException, 
    IllegalArgumentException, 
    InvocationTargetException {
        Class<?> pomclass = obj.getClass();
        pomclass = obj.getClass();
        Method[] methods = obj.getClass().getMethods();


        Map<String, Object> map = new HashMap<String, Object>();
        for (Method m : methods) {
           if (m.getName().startsWith("get") && !m.getName().startsWith("getClass")) {
              Object value = (Object) m.invoke(obj);
              map.put(m.getName().substring(3), (Object) value);
           }
        }
    return map;
}

	
	public String classificationStatusV2(String data, HttpServletRequest request){
        
        String result = "success";
       String token = null;
        try{
            Gson gson=new Gson();
             JSONParser parser = new JSONParser();  
            JSONObject json = (JSONObject) parser.parse(data);  
            JSONObject json1 = (JSONObject) parser.parse(gson.toJson(json.get("result")));
            // JSONObject json2 =(JSONObject) parser.parse(gson.toJson(json1.get("df")));
            // JSONArray arr = new JSONArray();
            Object obj=json.get("result");
            Object obj1=json1.get("df"); 
            // Classifymodel cm=new Classifymodel();
            List<Classifymodel> list=new ArrayList<Classifymodel>();
            list=(List<Classifymodel>)obj1;
            logger.info("@@@"+list);
            Iterator iterator=list.iterator();
            while(iterator.hasNext()){
                Object i=iterator.next();
                logger.info("###"+i);
                Map map=((Map)i);
                // for (Map.Entry<String,String> entry : map.entrySet())   //using keyset() method for iteration over keySet  
                // logger.info("Item: " + entry.getKey() + ", Price: " + entry.getValue());   
                // for (Object Capital : map.values())         //using values() for iteration over keys  
                // logger.info("Capiatl: " + Capital);   
                 
                // Iterator<Map.Entry> itr1 = map.entrySet().iterator();
                // while (itr1.hasNext()) {
                //     Map.Entry pair = itr1.next();
                //     logger.info("Map value** "+pair.getKey() + " : " + pair.getValue());
                // }
                
            }
            //  Map resultObj1 = ((Map)obj1);
                // iterating result Map for get documentId
                // Iterator<Map.Entry> itr = resultObj1.entrySet().iterator();
                // while (itr.hasNext()) {
                //     Map.Entry pair1 = itr.next();
                //     logger.info("@@@"+pair1.getKey() + " : " + pair1.getValue());
                // }
            
            Map resultObj = ((Map)json.get("result"));
                // iterating result Map for get documentId
                Iterator<Map.Entry> itr1 = resultObj.entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    logger.info("***"+pair.getKey() + " : " + pair.getValue());
                }
            // arr.put(data);
            // JSONObject jObj = arr.getJSONObject(0);
            // token = jObj.getString("token");
            // String data1 = data.toString();
            // JSONObject teste = new JSONObject();
            // String status = teste.getJSONObject("data").getString("token");
        //     // error=json.get("errors");
        //     // final JSONObject obj = new JSONObject(data);
        //     // final JSONArray geodata = obj.getJSONArray("geodata");
            // logger.info("result: "+json.getString("elapsed"));
            logger.info("status: "+obj1.toString());
        //     // logger.info("args: "+json.get("args"));
        //     // Object isError=json.get("errors");
        }catch(Exception e){
            e.printStackTrace();
            result="Exception: "+e.getStackTrace()[0].getLineNumber();
        }
        
        
        return data;
    
    }

    public String ExtractionStatus(String data,HttpServletRequest request){
        String resultRes = "Success";
        String documentId=null;
        String error=null;
        String status=null;
        String elapsed=null;
        String contract_name=null;
        String document_name=null;
        String document_type=null;
        logger.info("data: "+data);
        try{
            
            JSONParser parser = new JSONParser();  
            JSONObject json = (JSONObject) parser.parse(data);  
            // error=json.get("errors");
            logger.info("result: "+json.get("result"));
            logger.info("errors: "+json.get("errors"));
            logger.info("args: "+json.get("args"));
            Object isError=json.get("errors");
            
            // logger.info("Object isError: "+isError.toString());|| (isError.toString()).length()==0
            logger.info("isError length: "+(isError==null?"error having null value":""+isError.toString().length()));
            if(isError == null){
                status="ok";
                // logger.info("*******having null value**********");
                  Map resultObj = ((Map)json.get("result"));
                // iterating result Map for get documentId
                Iterator<Map.Entry> itr1 = resultObj.entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    logger.info(pair.getKey() + " : " + pair.getValue());
                    documentId=""+pair.getValue();
                    //  Connection connection = getConnection();
                }
               
                    if(documentId.isEmpty()){
                        throw new NullPointerException("documentId is missing!");
                        
                    }
               
                // getting arguments like document/contract name & document type
                Map args = ((Map)json.get("args"));
                
                // iterating arguments
                Iterator<Map.Entry> iterateArgs=args.entrySet().iterator();
                while(iterateArgs.hasNext()){
                     Map.Entry pair = iterateArgs.next();
                    logger.info(pair.getKey() + " : " + pair.getValue());
                    // try{
                        if(((String)pair.getKey()).equals("contract_name")){
                            contract_name=""+pair.getValue();
                        }else if(((String)pair.getKey()).equals("document_name")){
                            document_name=""+pair.getValue();
                        }else if(((String)pair.getKey()).equals("document_type")){
                            document_type=""+pair.getValue();
                        }
                   
                }
                
                    if(contract_name.isEmpty()){
                            
                            throw new NullPointerException("contract_name is missing!");
                        } 
                        if(document_name.isEmpty()){
                            
                            throw new NullPointerException("document_name is missing!");
                        } 
                        if(document_type.isEmpty()){
                           
                            throw new NullPointerException("document_type is missing!");
                        }
               
                    Connection connection = getConnection();
        		    SQLServerPreparedStatement statement = (SQLServerPreparedStatement) connection
        					.prepareStatement("{call UploadOnSuccessChangeStatus(?,?,?,?,?)}");
        			statement.setString(1, documentId);
        			statement.setString(2, status);
        			statement.setString(3, contract_name);
        			statement.setString(4, document_name);
        			statement.setString(5, document_type);
        		    logger.info("documentId:"+documentId);
        		    logger.info("status:"+status);
        
        		
        			boolean exeresult = statement.execute();
        			if (exeresult) {
        				ResultSet resultSet = statement.getResultSet();
        				if (resultSet.next()) {
        				    for(int i=1;i<=resultSet.getMetaData().getColumnCount();i++){
                                resultSet.getString(i);
                                logger.info("resultSet: ",resultSet.getString(i));
                            }
                            //  result ="Success "+ resultSet.getInt("result");
        				}
        
        				resultSet.close();
        			}
        			statement.close();
        			connection.close();
            }else if((isError.toString()).length()==0){
                status="ok";
                // logger.info("*******having null value**********");
                  Map resultObj = ((Map)json.get("result"));
                // iterating result Map for get documentId
                Iterator<Map.Entry> itr1 = resultObj.entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    logger.info(pair.getKey() + " : " + pair.getValue());
                    documentId=""+pair.getValue();
                    //  Connection connection = getConnection();
                }
               
                    if(documentId.isEmpty()){
                        throw new NullPointerException("documentId is missing!");
                        
                    }
               
                // getting arguments like document/contract name & document type
                Map args = ((Map)json.get("args"));
                
                // iterating arguments
                Iterator<Map.Entry> iterateArgs=args.entrySet().iterator();
                while(iterateArgs.hasNext()){
                     Map.Entry pair = iterateArgs.next();
                    logger.info(pair.getKey() + " : " + pair.getValue());
                    // try{
                        if(((String)pair.getKey()).equals("contract_name")){
                            contract_name=""+pair.getValue();
                        }else if(((String)pair.getKey()).equals("document_name")){
                            document_name=""+pair.getValue();
                        }else if(((String)pair.getKey()).equals("document_type")){
                            document_type=""+pair.getValue();
                        }
                   
                }
                
                    if(contract_name.isEmpty()){
                            
                            throw new NullPointerException("contract_name is missing!");
                        } 
                        if(document_name.isEmpty()){
                            
                            throw new NullPointerException("document_name is missing!");
                        } 
                        if(document_type.isEmpty()){
                           
                            throw new NullPointerException("document_type is missing!");
                        }
               
                    Connection connection = getConnection();
        		    SQLServerPreparedStatement statement = (SQLServerPreparedStatement) connection
        					.prepareStatement("{call UploadOnSuccessChangeStatus(?,?,?,?,?)}");
        			statement.setString(1, documentId);
        			statement.setString(2, status);
        			statement.setString(3, contract_name);
        			statement.setString(4, document_name);
        			statement.setString(5, document_type);
        		    logger.info("documentId:"+documentId);
        		    logger.info("status:"+status);
        
        		
        			boolean exeresult = statement.execute();
        			if (exeresult) {
        				ResultSet resultSet = statement.getResultSet();
        				if (resultSet.next()) {
        				    for(int i=1;i<=resultSet.getMetaData().getColumnCount();i++){
                                resultSet.getString(i);
                                logger.info("resultSet: ",resultSet.getString(i));
                            }
                            //  result ="Success "+ resultSet.getInt("result");
        				}
        
        				resultSet.close();
        			}
        			statement.close();
        			connection.close();
            }else
            {
                resultRes="Error is: "+isError;
                status="error";
                 Map resultObj = ((Map)json.get("result"));
                // iterating result Map for get documentId
                Iterator<Map.Entry> itr1 = resultObj.entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    logger.info(pair.getKey() + " : " + pair.getValue());
                    documentId=""+pair.getValue();
                    //  Connection connection = getConnection();
                }
               
                    if(documentId.isEmpty()){
                        throw new NullPointerException("documentId is missing!");
                        
                    }
                 Connection connection = getConnection();
        		    SQLServerPreparedStatement statement = (SQLServerPreparedStatement) connection
        					.prepareStatement("{call UploadOnSuccessChangeStatus(?,?,?,?,?)}");
        			statement.setString(1, documentId);
        			statement.setString(2, status);
        			statement.setString(3, contract_name);
        			statement.setString(4, document_name);
        			statement.setString(5, document_type);
        		    logger.info("documentId:"+documentId);
        		    logger.info("status:"+status);
        
        		
        			boolean exeresult = statement.execute();
        			if (exeresult) {
        				ResultSet resultSet = statement.getResultSet();
        				if (resultSet.next()) {
        				    for(int i=1;i<=resultSet.getMetaData().getColumnCount();i++){
                                resultSet.getString(i);
                                logger.info("resultSet: ",resultSet.getString(i));
                            }
                            //  result ="Success "+ resultSet.getInt("result");
        				}
        
        				resultSet.close();
        			}
        			statement.close();
        			connection.close();
            }
        }catch(Exception e){
            e.printStackTrace();
			resultRes = "Exception is: "+e.getMessage();
        }
        return resultRes;
    }

    
    private File convertMultiPartToFile(MultipartFile file ) throws IOException
    {
        File convFile = new File( file.getOriginalFilename() );
        FileOutputStream fos = new FileOutputStream( convFile );
        fos.write( file.getBytes() );
        fos.close();
        return convFile;
    }
     public String ClassificationStatusV3 (MultipartFile csvFile, String documentId,String errors,HttpServletRequest request) throws IOException, CsvException, SQLException{
        String result = "success";
        try{
            
            Gson gson=new Gson();
        List<Classifymodel> list=new ArrayList<Classifymodel>();
        list=save(csvFile);

        logger.info("GsonData: "+gson.toJson(list));
        Iterator it=list.iterator();
        while(it.hasNext()){
            Classifymodel cf=new Classifymodel();
            cf=(Classifymodel)it.next();
            logger.info("hasNext: " +cf.getClause());
             Connection connection = getConnection();
        		    SQLServerPreparedStatement statement = (SQLServerPreparedStatement) connection
        					.prepareStatement("{call InsertClassifyDocumentData(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
        			statement.setString(1, documentId);
        			statement.setString(2, cf.getSection());
        			
        			statement.setString(3, cf.getPageNumber());
        			statement.setString(4, cf.getClauseNo());
        			statement.setString(5, cf.getClause());
        			statement.setString(6, cf.getTag_1_Applicability());
        			statement.setString(7, cf.getTag_2_Area());
        			statement.setString(8, cf.getTag_3_CovenantType());
        			statement.setString(9, cf.getTag_4_CovenantTitle());
        			statement.setString(10, cf.getTag_5_CovenantDescription());
        			statement.setString(11, cf.getComplianceFrequency());
        			statement.setString(12, cf.getTriggerType());
        			statement.setString(13, cf.getFirstTriggerDate());
        			statement.setString(14, cf.getSubmissionPeriodEndDate());
        			statement.setString(15, cf.getThreshold());
        			statement.setString(16, cf.getSubmissionPeriod());
        			statement.setString(17, cf.getEndDate());
        		  //  logger.info("documentId:"+documentId);
        		  //  logger.info("status:"+status);statement.setInt(3,Integer(cf.getPageNumber()));
        
        		
        			boolean exeresult = statement.execute();
        			if (exeresult) {
        				ResultSet resultSet = statement.getResultSet();
        				if (resultSet.next()) {
                            //  result ="Success "+ resultSet.getInt("result");
        				}
        
        				resultSet.close();
        			}
        			statement.close();
        			connection.close();
        }
            
        }catch(Exception e){
            e.printStackTrace();
            result="Exception: "+e.getMessage();
        }
        
        
        return result;
    }
    
    public String ClassificationStatus (MultipartFile csvFile, String documentId,String status,String message,String errors,HttpServletRequest request) throws IOException, CsvException, SQLException{
        String result = "success";
        try{
            
            Gson gson=new Gson();
        List<Classifymodel> list=new ArrayList<Classifymodel>();
        list=save(csvFile);

        logger.info("GsonData: "+gson.toJson(list));
        Iterator it=list.iterator();
        while(it.hasNext()){
            Classifymodel cf=new Classifymodel();
            cf=(Classifymodel)it.next();
            logger.info("hasNext: " +cf.getClause());
             Connection connection = getConnection();
        		    SQLServerPreparedStatement statement = (SQLServerPreparedStatement) connection
        					.prepareStatement("{call InsertClassifyDocumentData(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
        			statement.setString(1, documentId);
        			statement.setString(2, cf.getSection());
        			statement.setString(3, cf.getPageNumber());
        			statement.setString(4, cf.getClauseNo());
        			statement.setString(5, cf.getClause());
        			statement.setString(6, cf.getTag_1_Applicability());
        			statement.setString(7, cf.getTag_2_Area());
        			statement.setString(8, cf.getTag_3_CovenantType());
        			statement.setString(9, cf.getTag_4_CovenantTitle());
        			statement.setString(10, cf.getTag_5_CovenantDescription());
        			statement.setString(11, cf.getComplianceFrequency());
        			statement.setString(12, cf.getTriggerType());
        			statement.setString(13, cf.getFirstTriggerDate());
        			statement.setString(14, cf.getSubmissionPeriodEndDate());
        			statement.setString(15, cf.getThreshold());
        			statement.setString(16, cf.getSubmissionPeriod());
        			statement.setString(17, cf.getEndDate());
        		  //  logger.info("documentId:"+documentId);
        		  //  logger.info("status:"+status);
        
        		
        			boolean exeresult = statement.execute();
        			if (exeresult) {
        				ResultSet resultSet = statement.getResultSet();
        				if (resultSet.next()) {
                            //  result ="Success "+ resultSet.getInt("result");
        				}
        
        				resultSet.close();
        			}
        			statement.close();
        			connection.close();
        }
            
        }catch(Exception e){
            e.printStackTrace();
            result="Exception: "+e.getMessage();
        }
        
        
        return result;
    } 
    
    public static List<Classifymodel> csvToTutorials(InputStream is) {
        List<Classifymodel> classifyRes = new ArrayList<Classifymodel>();
        Gson gson = new Gson();
        Classifymodel res;
        // Iterable<CSVRecord> csvRecords1=null;
    try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        CSVParser csvParser = new CSVParser(fileReader,
            CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());) {
        res=new Classifymodel();
    //   List<ClassifyResponse> ClassifyResponses = new ArrayList<ClassifyResponse>();

      Iterable<CSVRecord> csvRecords = csvParser.getRecords();
    // csvRecords1=csvRecords;
      for (CSVRecord csvRecord : csvRecords) {
        
          Classifymodel classifyResponse = new Classifymodel(
              csvRecord.get("Section"),
              csvRecord.get("Page Number"),
              csvRecord.get("Clause No."),
              csvRecord.get("Clause"),
              csvRecord.get("Tag 1: Applicability"),
              csvRecord.get("Tag 2: Area"),
              csvRecord.get("Tag 3: Covenant Type"),
              csvRecord.get("Tag 4: Covenant Title"),
              csvRecord.get("Tag 5: Covenant Description"),
              csvRecord.get("Compliance Frequency"),
              csvRecord.get("Trigger Type"),
              csvRecord.get("First Trigger Date"),
              csvRecord.get("Submission PeriodEnd Date"),
              csvRecord.get("Threshold"),
              csvRecord.get("Submission Period"),
              csvRecord.get("End Date")
              );
        logger.info("data: "+gson.toJson(csvRecord));
        classifyRes.add(classifyResponse);
      }

      return classifyRes;
    } catch (IOException e) {
    //   throw new RuntimeException("fail to parse CSV file: " + e.getMessage());
    }
    return classifyRes;
  }
  
  public List<Classifymodel> save(MultipartFile file) {
    Gson gson = new Gson();
    // String docId=documentId;
    List<Classifymodel> classifyRes=new ArrayList<Classifymodel>();
    try {
    // List<Classifymodel> classifyResponse
    classifyRes= csvToTutorials(file.getInputStream());
    // classifyRes=classifyResponse;
    
      logger.info("save: "+gson.toJson(classifyRes));
    //   repository.saveAll(tutorials);
    } catch (IOException e) {
        e.printStackTrace();
    //   throw new RuntimeException("fail to store csv data: " + e.getMessage());
    }
    return classifyRes;
  }
 
  
 

}




