Files you need to know:
* app.css: Application CSS
* index.html: Can be edited directly to customize, such as including meta, script and other tags.
* app.js: Contains any application owned component definitions and functions.
* app.variables.json: Contains any application variable definition.
