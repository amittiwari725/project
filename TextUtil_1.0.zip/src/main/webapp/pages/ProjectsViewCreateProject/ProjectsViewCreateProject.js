/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
var uploadDocumentRes = "";
Page.onReady = function() {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */

    Page.Widgets.button1.disabled = "true";
    Page.Widgets.downloadClassificationButton.disabled = "true";
    if (Page.Widgets.downloadExtractionStatus.caption == "Available for download")
        Page.Widgets.fileupload3.disabled = "false";
    else
        Page.Widgets.fileupload3.disabled = "true";
    console.log("file name: " + Page.Widgets.fileupload3_1.caption);
    // console.log("files", Page.Widgets.fileupload3_1.selectedFiles);

};

function getUrlVars() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi,
        function(m, key, value) {
            vars[key] = value;
        });
    return vars;
}
Page.table1_customRowAction = function($event, row) {
    console.log("get action button data: ", row);
    var res = Page.Variables.getClassifyWebAPI.invoke();

    console.log("res: ", res);
};

Page.uploadDocumentsWebAPIonSuccess = function(variable, data) {
    // debugger;
    var documentId = ((data.message + "").substr(20)).trim();
    // console.log("upload res: ", data);
    console.log("files", Page.Widgets.fileupload3_1.selectedFiles[0]);
    Page.Widgets.fileupload3_1.selectedFiles = [];

    if (documentId.length > 0) {

        // Page.Widgets.button1.disabled = "false";
        uploadDocumentRes = documentId;
        var sv = Page.Variables.executeUpdateDocIdonUpload;
        sv.setInput("documentId", documentId);
        sv.setInput("projectId", getUrlVars()["projectId"]);
        sv.invoke();
        var us = Page.Variables.executeUpdateStatus;
        us.setInput("projectId", getUrlVars()["projectId"]);
        us.setInput("stepName", Page.Widgets.uploadDocument.caption);
        us.invoke();
        // console.log("caption: ", Page.Widgets.label4.caption);
        // Page.Variables.executeGetStatus.invoke();
        Page.Widgets.fileUploadMessage.open();
    } else
        Page.Widgets.button1.disabled = "true";


};
Page.button1Click = function($event, widget, item, currentItemWidgets) {
    // var covenentRes = Page.Variables.getCovenantsWebAPI.invoke();
    // debugger;
    var sv = Page.Variables.getCovenantsWebAPI;
    sv.setInput("document_id", "520ba11e6d91090640ce828310aec34bd3b6fafb"); // Hardcode value ***********************************************
    sv.invoke();
    // console.log("sv.invoke()", sv.invoke());

};



Page.getCovenantsWebAPIonSuccess = function(variable, data) {
    console.log("getCovenantsWebAPIonSuccess: ", data);
    Page.Widgets.fileupload3.selectedFiles = [];
    var headers = {
        "Section": 'Section',
        "Page Number": "Page Number",
        "Clause No.": "Clause No.",
        "Clause": "Clause",
        "Tag 1: Applicability": "Tag 1: Applicability",
        "Tag 2: Area": "Tag 2: Area",
        "Tag 3: Covenant Type": "Tag 3: Covenant Type",
        "Tag 4: Covenant Title": "Tag 4: Covenant Title",
        "Tag 5: Covenant Description": "Tag 5: Covenant Description",
        "Compliance Frequency": "Compliance Frequency",
        "Trigger Type": "Trigger Type",
        "First Trigger Date": "First Trigger Date",
        "Submission PeriodEnd Date": "Submission PeriodEnd Date",
        "Threshold": "Threshold",
        "Submission Period": "Submission Period",
        "End Date": "End Date"
    };
    var itemsNotFormatted = data.result.secdf;
    var itemsFormatted = [];
    itemsNotFormatted.forEach((item) => {

        itemsFormatted.push({
            "Section": item["Section"].replace(/,/g, ''),
            "Page Number": item["Page Number"],
            "Clause No.": item["Clause No."],
            "Clause": item["Clause"].replace(/,/g, ''),
            "Tag 1: Applicability": item["Tag 1: Applicability"],
            "Tag 2: Area": item["Tag 2: Area"],
            "Tag 3: Covenant Type": item["Tag 3: Covenant Type"],
            "Tag 4: Covenant Title": item["Tag 4: Covenant Title"],
            "Tag 5: Covenant Description": item["Tag 5: Covenant Description"],
            "Compliance Frequency": item["Compliance Frequency"],
            "Trigger Type": item["Trigger Type"],
            "First Trigger Date": item["First Trigger Date"],
            "Submission PeriodEnd Date": item["Submission PeriodEnd Date"],
            "Threshold": item["Threshold"],
            "Submission Period": item["Submission Period"],
            "End Date": item["End Date"]
        });
    });
    console.log("itemsFormatted: ", itemsFormatted);
    var fileTitle = 'Loan Agreement';
    exportCSVFile(headers, itemsFormatted, fileTitle); // call the exportCSVFile() function to process the JSON and trigger the download
    Page.Widgets.fileupload3.disabled = "false";
};

function exportCSVFile(headers, items, fileTitle) {
    if (headers) {
        items.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });
    debugger;
    console.log(blob);
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        debugger;
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}

function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ',';

            line += array[i][index];
        }

        str += line + '\r\n';
    }

    return str;
}

Page.uploadDocumentsWebAPI2onSuccess = function(variable, data) {
    var documentId = ((data.message + "").substr(20)).trim();
    console.log("res 2 ", data);
    if (documentId.length > 0) {
        Page.Widgets.downloadClassificationButton.disabled = "false";
        // uploadDocumentRes = documentId;
    } else
        Page.Widgets.downloadClassificationButton.disabled = "true";
};
Page.downloadClassificationButtonClick = function($event, widget, item, currentItemWidgets) {
    var classifyRes = Page.Variables.getClassifyDocumentData;
    var csvFileData = [];



    classifyRes.listRecords({}, function(data) {
            csvFileData = data

            var csvHeader = [
                "Section", "Page Number", "Clause No.", "Clause", "Tag 1: Applicability", "Tag 2: Area", "Tag 3: CovenantType", "Tag 4: CovenantTitle", "Tag 5: CovenantDescription", "Compliance Frequency", "Trigger Type", "First Trigger Date", "Submission PeriodEnd Date", "Threshold", "Submission Period", "End Date"
            ]
            var x = new Array(csvFileData.length);
            for (var i = 0; i < csvFileData.length; i++) {
                console.log("data: ", csvFileData[i]);
                var result = Object.keys(csvFileData[i]).map((key) => [(key), csvFileData[i][key]]);

                console.log(result);
                console.log("length: ", result.length);
                x[i] = new Array((result.length - 2));
                if (i == 0) {
                    // csvHeader
                    for (var j = 0; j < csvHeader.length; j++) {
                        x[i][j] = csvHeader[j];
                    }

                }
                if (i != 0) {
                    for (var j = 0; j < result.length - 2; j++) {
                        x[i][j] = result[j + 2][1];
                    }
                }
            }
            console.log("ND array: ", x);


            exportToCsv1('Loan Agreement.csv', x);

        },
        function(error) {
            // Error Callback
            console.error('error', error)
        });
    Page.Variables.getClassifyDocumentData.listRecords();
    // console.log("classifyRes: ", classifyRes.listRecords());
};
Page.refreshWidgetClick = function($event, widget) {
    Page.Variables.executeGetStatus.setInput("projectId", getUrlVars()["projectId"]);
    Page.Variables.executeGetStatus.setInput("stepName", Page.Widgets.uploadDocument.caption);
    Page.Variables.executeGetStatus.invoke();
    Page.Variables.executeGetStatusForClassify.setInput("projectId", getUrlVars()["projectId"]);
    Page.Variables.executeGetStatusForClassify.setInput("stepName", Page.Widgets.startClassification.caption);
    Page.Variables.executeGetStatusForClassify.invoke();
    if (Page.Widgets.downloadExtractionStatus.caption == "Available for download")
        Page.Widgets.fileupload3.disabled = "false";
    else
        Page.Widgets.fileupload3.disabled = "true";
};

Page.executeGetStatusonSuccess = function(variable, data) {
    // debugger;
    console.log(data.content[0].stepStatus);
    if (data.content[0].stepStatus == "completed") {
        Page.Widgets.button1.disabled = "false";
        Page.Widgets.downloadExtractionStatus.caption = "Available for download";
    } else {
        Page.Widgets.button1.disabled = "true";
        Page.Widgets.downloadExtractionStatus.caption = "Not available for download";
    }

    if (Page.Widgets.downloadExtractionStatus.caption == "Available for download")
        Page.Widgets.fileupload3.disabled = "false";
    else
        Page.Widgets.fileupload3.disabled = "true";


};

Page.executeGetStatusForClassifyonSuccess = function(variable, data) {
    console.log("executeGetStatusForClassifyonSuccess: " + data.content[0]);
    if (data.content[0].stepStatus == "completed") {
        Page.Widgets.fileupload3.disabled = "false";
        Page.Widgets.downloadClassificationButton.disabled = "false";
        Page.Widgets.downloadClassificationStatus.caption = "Available for download";
    } else {
        Page.Widgets.fileupload3.disabled = "true";
        Page.Widgets.downloadClassificationButton.disabled = "true";
        Page.Widgets.downloadClassificationStatus.caption = "Not available for download";
    }
    if (Page.Widgets.downloadExtractionStatus.caption == "Available for download")
        Page.Widgets.fileupload3.disabled = "false";
    else
        Page.Widgets.fileupload3.disabled = "true";
};




function CSVtoArray(text1) {
    var text = JSON.stringify(text1);
    // jsonObject jsonObj = new jsonObject();
    // var text = jsonObj.toString(text1);
    console.log("text ", text);
    // console.log("text1 ", text1);
    var re_valid = /^\s*(?:'[^'\\]*(?:\\[\S\s][^'\\]*)*'|"[^"\\]*(?:\\[\S\s][^"\\]*)*"|[^,'"\s\\]*(?:\s+[^,'"\s\\]+)*)\s*(?:,\s*(?:'[^'\\]*(?:\\[\S\s][^'\\]*)*'|"[^"\\]*(?:\\[\S\s][^"\\]*)*"|[^,'"\s\\]*(?:\s+[^,'"\s\\]+)*)\s*)*$/;
    var re_value = /(?!\s*$)\s*(?:'([^'\\]*(?:\\[\S\s][^'\\]*)*)'|"([^"\\]*(?:\\[\S\s][^"\\]*)*)"|([^,'"\s\\]*(?:\s+[^,'"\s\\]+)*))\s*(?:,|$)/g;
    // Return NULL if input string is not well formed CSV string.
    if (!re_valid.test(text)) return null;
    var a = []; // Initialize array to receive values.
    text.replace(re_value, // "Walk" the string using replace with callback.
        function(m0, m1, m2, m3) {
            // Remove backslash from \' in single quoted values.
            if (m1 !== undefined) a.push(m1.replace(/\\'/g, "'"));
            // Remove backslash from \" in double quoted values.
            else if (m2 !== undefined) a.push(m2.replace(/\\"/g, '"'));
            else if (m3 !== undefined) a.push(m3);
            return ''; // Return empty string.
        });
    // Handle special case of empty last value.
    if (/,\s*$/.test(text)) a.push('');
    return a;
}


function exportToCsv1(filename, rows) {
    var processRow = function(row) {
        var finalVal = '';
        for (var j = 0; j < row.length; j++) {
            var innerValue = row[j] === null ? '' : row[j].toString();
            if (row[j] instanceof Date) {
                innerValue = row[j].toLocaleString();
            };
            var result = innerValue.replace(/"/g, '""');
            if (result.search(/("|,|\n)/g) >= 0)
                result = '"' + result + '"';
            if (j > 0)
                finalVal += ',';
            finalVal += result;
        }
        return finalVal + '\n';
    };

    var csvFile = '';
    for (var i = 0; i < rows.length; i++) {
        csvFile += processRow(rows[i]);
    }

    var blob = new Blob([csvFile], {
        type: 'text/csv;charset=utf-8;'
    });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, filename);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", filename);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}



// exportToCsv('export.csv', [
// 	['name','description'],	
//   ['dav,id','123'],
//   ['jona','""'],
//   ['a','b'],

// ])
Page.button4Click = function($event, widget) {
    var lv = Page.Variables.executeGetProjectDataInfo;
    lv.setInput("ProjectId", getUrlVars()["projectId"]);
    lv.invoke();
    var sv = Page.Variables.getCovenantsWebAPI;
    sv.setInput("document_id", "520ba11e6d91090640ce828310aec34bd3b6fafb"); //******************hardcode***************
    sv.invoke();
};

// Page.executeGetProjectDataonSuccess = function(variable, data) {

//     var result = Object.keys(data.content).map((key) => [(key), data.content[key]]);
//     var obj = data.content[0];
//     uploadDocumentRes = obj.documentId;
//     console.log("uploadDocumentRes: " + uploadDocumentRes);
//     // console.log("getProjectData :", JSON.stringify(data.content[0]));
// };

Page.executeGetProjectDataInfoonSuccess = function(variable, data) {
    var result = Object.keys(data.content).map((key) => [(key), data.content[key]]);
    var obj = data.content[0];
    uploadDocumentRes = obj.documentId;
    console.log("uploadDocumentRes: " + uploadDocumentRes);
};
Page.fileupload3_1Select = function($event, widget, selectedFiles) {
    console.log("selectedFiles: " + selectedFiles);
};

Page.UploadClassifyRestServiceonSuccess = function(variable, data) {
    debugger;
    console.log("files", Page.Widgets.fileupload3_1.selectedFiles[0]);
    Page.Widgets.fileupload3.selectedFiles = [];
    var itemsNotFormatted = data.result.df;
    // var itemsFormatted = new Array(itemsNotFormatted.length);
    // itemsNotFormatted.forEach((item) => {

    //     // itemsFormatted=
    //     // push({
    //     //     Object.entries(item)

    //     // });
    // });

    // for (var i = 0; i < itemsNotFormatted.length; i++) {
    //     itemsNotFormatted[i] = Object.entries(itemsNotFormatted[i])
    //     console.log("item: " + itemsNotFormatted[i]);
    // }
    console.log("itemsNotFormatted: " + JSON.stringify(data));
    // console.log("UploadClassifyRestServiceonSuccess: " + data.result.df);
};
Page.fileupload3_2Select = function($event, widget, selectedFiles) {
    debugger;
    console.log("selectedFiles: " + selectedFiles[0].name);
    Page.Widgets.startClassificationDocumentName.caption = selectedFiles[0].name;
};
