/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function() {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
    // Page.Widgets.label1.show = false;
    // Page.Widgets.contractNameTextBox.show = false;
    // Page.Widgets.submitData.show = false;
    // Page.Widgets.radioset1.target.ariaChecked = true
};

Page.radioset1Change = function($event, widget, newVal, oldVal) {
    console.log("radioset value: ", $event, widget, newVal, oldVal);
    if (newVal + "" === "Select ADHOC document") {
        Page.Widgets.label1.show = true;
        Page.Widgets.contractNameTextBox.show = true;
        Page.Widgets.submitData.show = true;
    } else if (newVal + "" === "Select existing contract") {
        Page.Widgets.label1.show = false;
        Page.Widgets.contractNameTextBox.show = false;
        Page.Widgets.submitData.show = false;
    }
};

Page.submitContractNameClick = function($event, widget) {
    console.log("text value: " + Page.Widgets.contractNameTextBox.datavalue);
    var setTextInput = Page.Variables.executeCreateProject;
    // setTextInput.setInput("contractName", Page.Widgets.contractNameTextBox.datavalue);
    setTextInput.invoke({
        "inputFields": {
            "contractName": Page.Widgets.contractNameTextBox.datavalue
        }
    }, function(data) {
        // Success Callback 
        console.log("success", data);
        Page.App.Actions.goToPage_ProjectsCreateProject.invoke();
    }, function(error) {
        // Error Callback
        console.log("error", error)
    });
};

Page.executeCreateProjectonSuccess = function(variable, data) {
    console.log("executeCreateProjectonSuccess: " + data);
};
