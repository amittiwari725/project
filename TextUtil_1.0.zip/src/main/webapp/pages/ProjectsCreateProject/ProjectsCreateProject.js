/*
 * Use App.getDependency for Dependency Injection
 * eg: var DialogService = App.getDependency('DialogService');
 */

/* perform any action on widgets/variables within this block */
Page.onReady = function() {
    /*
     * variables can be accessed through 'Page.Variables' property here
     * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
     * Page.Variables.loggedInUser.getData()
     *
     * widgets can be accessed through 'Page.Widgets' property here
     * e.g. to get value of text widget named 'username' use following script
     * 'Page.Widgets.username.datavalue'
     */
    console.log(Page.Widgets.select1.datavalue);
    console.log(Page.Widgets.select2.displayValue);
};

Page.createProjectClick = function($event, widget) {

};

Page.label17Click = function($event, widget, item, currentItemWidgets) {
    Page.App.Actions.goToPage_ProjectsViewCreateProject.setData({
        "projectId": item.projectId
    });
    Page.App.Actions.goToPage_ProjectsViewCreateProject.invoke();
};

Page.executeViewProjectsonSuccess = function(variable, data) {
    console.log("data: " + data);
    console.log(Page.Widgets.select1.datavalue);
    console.log(Page.Widgets.select2.datavalue);
};
Page.label16Click = function($event, widget, item, currentItemWidgets) {
    Page.App.Actions.goToPage_ProjectsViewCreateProject.setData({
        "projectId": item.projectId
    });
    Page.App.Actions.goToPage_ProjectsViewCreateProject.invoke();
};
